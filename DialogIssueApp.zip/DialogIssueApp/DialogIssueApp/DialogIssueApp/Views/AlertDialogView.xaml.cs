﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace DialogIssueApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AlertDialogView : Grid
    {
        public AlertDialogView()
        {
            InitializeComponent();
        }
    }
}