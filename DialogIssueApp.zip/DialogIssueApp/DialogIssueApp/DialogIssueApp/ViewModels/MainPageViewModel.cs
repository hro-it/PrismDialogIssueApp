﻿using Prism.Commands;
using Prism.Navigation;
using Prism.Services.Dialogs;

namespace DialogIssueApp.ViewModels
{
    public class MainPageViewModel : ViewModelBase
    {
        private IDialogService dialogService;

        public MainPageViewModel(INavigationService navigationService, IDialogService dialogService)
            : base(navigationService)
        {
            Title = "Main Page";
            this.dialogService = dialogService;
        }

        private DelegateCommand breakApp;

        public DelegateCommand BreakApp
        {
            get
            {
                return breakApp ?? (breakApp = new DelegateCommand(
                    () =>
                    {
                        dialogService.ShowDialog("AlertDialogView?title=Broke&message=You are going to break this app when you press OK.");
                    }));
            }
        }

        private DelegateCommand keepAppAlive;

        public DelegateCommand KeepAppAlive
        {
            get
            {
                return keepAppAlive ?? (keepAppAlive = new DelegateCommand(
                    () =>
                    {
                        dialogService.ShowDialog("AlertDialogView?title=It's Alive&message=You will keep this app alive when you " +
                            "press the OK buttton.", r => { });
                    }));
            }
        }
    }
}
