﻿using Prism.AppModel;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;

namespace DialogIssueApp.ViewModels
{
    public class AlertDialogViewModel : BindableBase, IDialogAware, IAutoInitialize
    {
        public event Action<IDialogParameters> RequestClose;

        private string title = "Title";

        public string Title
        {
            get => title;
            set => SetProperty(ref title, value);
        }

        private string message = "Message";

        [AutoInitialize(true)]
        public string Message
        {
            get => message;
            set => SetProperty(ref message, value);
        }

        public AlertDialogViewModel()
        {
            CloseCommand = new DelegateCommand(() => { RequestClose?.Invoke(null); });
        }

        public DelegateCommand CloseCommand { get; }

        public bool CanCloseDialog() => true;

        public void OnDialogClosed() { }

        public void OnDialogOpened(IDialogParameters parameters) { }
    }
}